import json
from pathlib import Path
from time import perf_counter
from f1tenth_benchmarks.research.core.geometry import load_geometry
from f1tenth_benchmarks.research.overtaking.millimetre_domain import MillimetreDomain
from f1tenth_benchmarks.research.overtaking.mm_bspline_repair import BudgetedDomainGenerator
from f1tenth_benchmarks.research.overtaking.session import SessionConfig, make_plan

root = Path(__file__).parent
geometry = load_geometry('maps/frenet/my_map/geometry', 'maps/my_map.yaml', inspect=True)
domain = MillimetreDomain.load('Data/research/overtaking/mm_domain_20261030_width20_clearance5_001/domain', geometry, expected_margin=.15)
states = [json.loads(s) for s in Path('Data/research/overtaking/mm_reference_c3_20261030_001/session/states.jsonl').read_text().splitlines()]
config = SessionConfig(safety_margin_m=.15, query_mode='exact', generation_mode='direct_only').for_map('my_map')
rows = []
for budget in (.02, .04, .08):
    generator = BudgetedDomainGenerator(domain, budget_s=budget)
    for step in (34, 35):
        started = perf_counter()
        event = make_plan(geometry, states[step], config, step, generator=generator)
        row = dict(budget_s=budget, step=step, elapsed_s=perf_counter()-started, event=event)
        rows.append(row)
        print(json.dumps(dict(budget_ms=budget*1000, step=step,
            elapsed_ms=row['elapsed_s']*1000, valid=[p['candidate_id'] for p in event['paths'] if p['sampled_valid']],
            repair=event['result']['bspline_repair'])), flush=True)
(root/'report.json').write_text(json.dumps(rows, indent=2, allow_nan=False)+'\n')
