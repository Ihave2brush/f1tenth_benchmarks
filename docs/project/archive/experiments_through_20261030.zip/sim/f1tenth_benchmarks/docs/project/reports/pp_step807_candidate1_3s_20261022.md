# 第 807 步候選一：Pure Pursuit 固定路徑追蹤 3 秒

日期：2026-10-22。這是獨立分岔實驗，原始完整圈資料與原播放服務不變；不重新生成候選，也不把整圈中線軌跡冒充候選追蹤。

## 初始狀態與控制

來源為本機 `Data/research/overtaking/40m_every_step_20261021_001/` 的第 807 步（原模擬絕對時間 80.8 s、相對時間 80.7 s），候選一 sampled_valid=true。載入該步完整七維 physical_state 與 steering_buffer，保留速度、yaw rate、slip 與轉向延遲；不額外 reset 或做初始化前進。

先使用保存的 pre_step_state、pre_step_steering_buffer 與上一個控制命令重播十個物理子步，確認可重現來源車況，再從該狀態追蹤固定候選一。沿用既有 PP 的最近折線點、圓交點及 get_actuation 公式；候選為開放路徑，wrap=false，不把終點連回起點。

速度目標 1.2 m/s、PP 前視 0.6 m、軸距 0.33 m、轉向上限 0.4 rad；控制週期 0.1 s、物理週期 0.01 s，使用原 DynamicsSimulator 的車輛模型與 steering delay。這是單條已保存路徑的追蹤，沒有候選更新或超車決策。

## 結果

| 項目 | 實測 |
|---|---:|
| 模擬時間 | 3.0 s |
| 控制區間／物理子步 | 30／300 |
| 行駛距離 | 3.60 m |
| 全部物理樣本最大中心點到候選折線距離 | 0.00390148 m（約 3.90 mm） |
| 結尾距離誤差 | 0.00236191 m（約 2.36 mm） |
| 轉向飽和次數 | 0 |
| 碰撞 | 既有模擬器四角法未偵測到，每個物理子步檢查 |
| 來源區間重播／新實驗重播 | 通過／通過，狀態 atol=1e−12，steering buffer 一致 |

新實驗另從原保存狀態，以已記錄的三十個命令逐物理步重播，核對全部三百個狀態。開放路徑不閉合、實際航向影響控制與轉向限制兩項 unittest 均通過；沒有重跑全量研究測試。

目前碰撞檢查是既有 simulator 的旋轉矩形四個角落，不是矩形內部、邊緣或連續 swept footprint 證明。此結果也不替未行駛的候選部分背書。

## 結果如何解讀

三秒只走過 40 m 候選的開頭約 3.6 m；終點投影所在的候選 d 約 −0.02430 m，因此畫面上剛開始的橫向分離很小，兩條線幾乎重疊是實測結果，不是沒有切換候選。這次能證明該來源狀態下初段可由 PP 追蹤，不能推論整條候選、末段或其他車速也能跟上。

本機產物：`Data/research/overtaking/pp_step807_candidate1_3s_20261022_001/`，包含 experiment.json（物理樣本／命令／固定候選點）、summary.json、trajectory.png 與 playback.gif。JSON 保存來源 state／plan record SHA256、地圖版本與執行程式 SHA256。

動畫顯示控制步 0～30、每格 0.1 s；GIF 含初始畫面而展示約 3.1 s，實際模擬精確為 3.0 s。青線為候選一、橙線為實際車輛中心軌跡、紫叉為 PP 前視點；這裡的 GIF 留在本機，未嵌入 repository 的大型原始資料。

## 重現

從 repository 根目錄，在既有模擬 Python 環境使用新的輸出目錄：

```bash
python -B -m f1tenth_benchmarks.research.run_recorded_candidate_pp \
  --session Data/research/overtaking/40m_every_step_20261021_001 \
  --step 807 --candidate 1 --duration 3 \
  --output-dir Data/research/overtaking/NEW_PP_EXPERIMENT
python -B -m unittest discover -s tests/research -p test_recorded_candidate_pp.py -v
```

程式見 [run_recorded_candidate_pp.py](../../../f1tenth_benchmarks/research/run_recorded_candidate_pp.py)。來源完整圈需在本機存在，程式不重新產生它。執行會拒絕覆寫已存在的輸出目錄。

## 第二次實驗：重新生成 10 m 候選，再固定追蹤 5 秒

同樣從第 807 步 physical_state／steering buffer 出發，使用同版本原圖幾何與 V5.2 重新生成五候選，只有候選前視從 40 m 改成 10 m；不是截取舊 40 m 曲線的前十公尺。速度 1.2 m/s、PP 前視 0.6 m、margin 各側 0.2 m，以及其餘求解／修正限制皆不變。

新候選生成耗時 4.54018 s，四條取樣通過；候選一有效，每條密集取樣 401 點。之後只固定追蹤新候選一，不在五秒內重新規劃。

| 項目 | 第二次實測 |
|---|---:|
| 候選前視／追蹤時間 | 10 m／5.0 s |
| 控制區間／物理子步 | 50／500 |
| 行駛距離 | 6.00 m |
| 最大／末端追蹤誤差 | 0.01189668 m／0.01189668 m（約 1.19 cm） |
| 最後投影位置的候選 d | −0.468696 m（中線右側約 46.9 cm） |
| 轉向飽和 | 0 |
| 四角碰撞檢查 | 未偵測到碰撞，每 0.01 s 檢查 |
| 來源區間與五秒命令重播 | 全數通過 |

產物另存 `Data/research/overtaking/pp_step807_h10_candidate1_5s_20261022_001/`，含 regenerated_plan.json、experiment.json、summary.json、trajectory.png、playback.gif。原始整圈與第一次實驗不變。GIF 為 51 個控制樣本的展示，模擬時間精確五秒；尚未行駛全部十公尺，無完整 swept footprint 證明，4.54 s 生成亦非即時。

重現時另加 `--regenerate-lookahead 10 --duration 5` 並指定新的輸出目錄。新增選項後兩項開放路徑／轉向限制 unittest 重驗通過（0.089 s）；來源一致、401 點、51 個控制樣本與 501 個物理樣本已核對。

### 五候選地圖與動畫補充

已另輸出全圖 map_overview.png、807 步初始局部圖 map_step807.png、結尾 trajectory.png 與五線 playback.gif，位於第二次實驗目錄的 `five_candidates_with_diagnostic/`。

候選一至四為已保存的取樣通過曲線。候選五原結果為 optimizer_constraints_not_satisfied，未保存點列；為顯示第五條線，另外重現相同輸入的三個第一輪求解，核對 status 與 objective 和原 attempts 相符，選約束最小殘差最接近零的 road_fraction 失敗解。以紫色虛線標為 failed solve, diagnostic；另存 candidate5_diagnostic.json。該曲線未做密集驗證、未被接受、沒有交給 PP，也不回寫原 regenerated_plan.json。

動畫仍使用相同五秒模擬樣本；紅色為車身與實際軌跡，只有候選一被追蹤。新增圖像重製不改寫原有物理樣本與模擬結果。

圖例修正與候選五約束分析已集中在[807 步路線五震盪與追蹤驗證](2026-10-22_807步10m路線五震盪與追蹤驗證.md)，以其中修正版圖片／動畫為準。
