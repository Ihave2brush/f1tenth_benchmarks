# 三號定義修正：整段參考中線，與車況銜接軌跡分開

2026-10-30。MY map、PP 0.3 m、車寬 20 cm、車長 58 cm、速度 1.2 m/s、0.1 s 控制週期、3 m 候選前視。安全設定仍是中心 15 cm 預篩；沒有放寬道路或曲率限制。

## 正確定義

三號為 **reference_centerline 參考路徑：整段 d=0，方向沿參考中線**。它不需要穿過車輛當下偏移的位置，也不需要以車頭方向作起始切線。控制器讀取車況、追蹤中線並修正誤差。先前從實際 d／yaw 生成的 Hermite 接回線，屬於另一種 state_matched_trajectory，不能和中線參考混為一談。

一、二、四、五號仍是從實際狀態出發的銜接軌跡，保留原起點／方向閘門；舊 centerline_return 與 terminal_width 策略保留供明確選擇的對照，不作新預設。

## 驗證分流，沒有取消安全檢查

- 三號獨立檢查整個前視區間的道路域與參考曲率，不從外側 Hermite 家族繼承結果，因為它不和四條側向軌跡共用實際起點。
- 新參考路徑契約只允許 candidate_id=3；其 spline 必須整段係數為 0、範圍正確，來源 s 必須匹配獨立實際車位投影，第一點／方向必須匹配真正參考曲線。不能只改 path_type 字串就繞過檢查。
- 車輛偏移與方向誤差仍需落在設定的追蹤範圍內。這是既有追蹤界限，不是完整 recovery／車身安全證明。
- 原實際起點誤差仍保存為追蹤資訊，另保存 reference_contract_check。verify_session 與候選獨立重驗按不同型別核對，保留歷史紀錄相容性。
- 合格三號標記 fallback_candidate_id=3。沒有合格路徑時 requires_stop=true，不強迫放行不安全中線；目前候選未接管控制，這個欄位是狀態回報，尚未連接實車制動。

## 完整圈結果

| 項目 | 結果 |
|---|---:|
| 完整圈 | 1，無碰撞；101 控制區間、102 組規劃 |
| 三號參考可用 | **102／102** |
| 沒有任何候選的步數 | **0**，舊第 34、35 步已保留三號 |
| 平均合格候選／5 | 2.775 |
| 規劃中位數 | 3.52 ms |
| 完整控制步中位數／P95／最大 | 4.96／5.70／17.21 ms |
| 控制步超過 100 ms | 0／101 |
| 原密度獨立 exact 幾何／折線重驗 | 283 條次，0 失敗 |
| 三號 1 mm 獨立重驗 | 第 34、35、40 步，各 3,001 點，全部通過 |
| session 獨立重播 | 物理／PP 命令／Frenet／圈數／索引／型別契約均通過 |

車況與實際控制命令和上一輪 PP=0.3 m 完全一致；本輪修正的是候選定義與驗證契約，不是改變 PP 行為。四條側向提案的既有問題仍存在；不能把三號可用說成已修好所有 Hermite 銜接。

相關回歸 **61 passed**，18 項既有 Matplotlib/Pyparsing 棄用警告。測試包含參考偏移允許、偽造非零 spline／來源 s／第一點／candidate_id 拒絕、狀態軌跡不可借用例外、追蹤範圍拒絕、中線邊界／曲率失敗不強制放行、舊 session 與播放相容性。

## 第 34、35 步修正後圖片

綠色三號與黑虛線中線重合。第 34 步三號最大曲率約 **1.1364 /m**，第 35 步約 **1.0863 /m**，都低於 **1.281192 /m**。這些是中線本身的曲率，不是上一輪強制 Hermite 接回線的曲率。

![第34步](figures/mm_reference_c3_20261030/step_34.png)

![第35步](figures/mm_reference_c3_20261030/step_35.png)

完整資料：[report.json](../../../Data/research/overtaking/mm_reference_c3_20261030_001/report.json)、[獨立重播](../../../Data/research/overtaking/mm_reference_c3_20261030_001/verification.json)、[繪圖數據](figures/mm_reference_c3_20261030/diagnostics.json)。可重現腳本與 session 在 report 同目錄。

這輪只證明目前 my_map 與車況下，中線參考可以持續保留。完整車身外緣 5 cm、連續掃掠、動態 recovery、候選接管與實車部署仍未完成；planning_allowed／footprint_verified 維持 false。沒有 commit／push。
